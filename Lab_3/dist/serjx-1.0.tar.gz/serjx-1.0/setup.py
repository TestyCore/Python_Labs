from setuptools import setup

setup(name='serjx',
      version='1.0',
      description='Serializer',
      packages=['Lab_3', 'Lab_3/helpers', 'Lab_3/serializers'],
      author_email='tatarinov.slava222@gmail.com',
      zip_safe=False)
